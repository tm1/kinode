Utility set for Interbase/Firebird.
 Oleg Loa (loa@mail.ru)

1) gdrop - tool to drop metadata objects. Support
deleting of dependent objects.


Syntax: gdrop [options]
  -database "database name"
  -user     "user name"
  -password "password"
  -silent   = silent processing
  -ce       = commit after each object
  -v {view1 view2 ... viewN |*}
  -p {sproc1 sproc2 ... sprocN |*}
  -t {trigger1 trigger2 ... triggerN |*}
  -i {index1 index2 ... indexN |*}
  -c {constraint1 constraint2 ... constraintN |*}
  -x {exception1 exception2 ... exceptionN |*}
  -f {udf1 udf2 ... udfN |*}

2) gidx - tool to update index statistics. Issues "set statistics index xxx"
for defined index set.

Syntax: gidx
 -user       default user name
 -password   default password
 -c          commit after each index
 -s          include system defined indices
"database name"

3) gkill - tool to kill database file in extraordinary situations.

Attention!!! Running this tool you will completely destroy specified
database structure (table data).

Sintax: gkill
 -user       default user name
 -password   default password
 -u          clear user table data pages
 "database name"
